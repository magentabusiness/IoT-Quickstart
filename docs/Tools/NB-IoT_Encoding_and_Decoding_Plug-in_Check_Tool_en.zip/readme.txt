NB-IoT Encoding and Decoding Plug-in Check Tool
              |
              |---- NB-IoT Encoding and Decoding Plug-in Check Tool Instructions.doc     : Tool User Guide, read it before using the tool
              |---- pluginDetector.jar                                                   : Tool
              |---- package.zip                                                          : Examples of plugin
              |---- devicetype-capability.json                                           : Device capability description file��you can get it from the profile( path is deviceType_manufacturerId_model/profile/devicetype-capability)
              |---- tool                                                                 : Files required for the tool